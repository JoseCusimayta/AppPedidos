package yiwo.apppedidos.Fragment;

import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import yiwo.apppedidos.AspectosGenerales.CodigosGenerales;
import yiwo.apppedidos.Data.BDActivarFunciones;
import yiwo.apppedidos.R;
import yiwo.apppedidos.ConexionBD.BDConexionSQLite;


public class FragSplashScreen extends Fragment {

    BDConexionSQLite myDb;
    TextView tv_link;
    String TAG = "FragSplashScreen";
    BDActivarFunciones bdActivarFunciones = new BDActivarFunciones();

    public FragSplashScreen() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_splash_screen, container, false);
        tv_link = view.findViewById(R.id.tv_link);
        myDb = new BDConexionSQLite(getContext());
        try {

            BackGroundTask task = new BackGroundTask();
            task.execute("");

        } catch (Exception e) {
            Log.d(TAG, "onCreateView "+e.getMessage());
        }
        return view;
    }


    public void CambiarFragment(Fragment fragment) {
        assert getFragmentManager() != null;
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out, R.anim.fade_in, R.anim.fade_out);
        transaction.replace(R.id.frag_contenedor, fragment);
        transaction.commit();
    }


    //region Tarea en Segundo Plano con ListView
    public class BackGroundTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                bdActivarFunciones.ActualizarFunciones();
                //region Revisando si existe un usuario que ha iniciado sesion
                Cursor res = myDb.getAllData();
                if (res.getCount() == 0) {
                    CodigosGenerales.Login = false; //Activar el Booleano para decir al programa que se ha iniciado sesión previamente
                } else {
                    CodigosGenerales.Login = true;
                }
                //endregion

                //region Verificar si el usuario ha ingresado previamente obteniendo los datos del SQLITE
                if (CodigosGenerales.Login) {
                    //region Configuración para cuando ya se ha iniciado sesión previamente
                    List<String> datos_usuario = new ArrayList();
                    while (res.moveToNext()) {
                        datos_usuario.add(res.getString(1));//Obtener el Codigo_Empresa
                        datos_usuario.add(res.getString(2));//Obtener el Codigo_PuntoVenta
                        datos_usuario.add(res.getString(3));//Obtener el Codigo_Almacen
                        datos_usuario.add(res.getString(4));//Obtener el Codigo_Usuario
                        datos_usuario.add(res.getString(5));//Obtener el Codigo_CentroCostos
                        datos_usuario.add(res.getString(6));//Obtener el Codigo_UnidadNegocio
                        datos_usuario.add(res.getString(7));//Obtener el Tipo_Moneda
                        datos_usuario.add(res.getString(8));//Obtener la direccion del almacen
                        datos_usuario.add(res.getString(9));//Obtener el Nombre del Vendedor
                        datos_usuario.add(res.getString(10));//Obtener el Celular del Vendedor
                        datos_usuario.add(res.getString(11));//Obtener el email del Vendedor
                    }
                    CodigosGenerales.Codigo_Empresa = datos_usuario.get(0);   //Guardar el Codigo_Empresa en CodigosGenerales
                    CodigosGenerales.Codigo_PuntoVenta = datos_usuario.get(1);   //Guardar el Codigo_PuntoVenta en CodigosGenerales
                    CodigosGenerales.Codigo_Almacen = datos_usuario.get(2);   //Guardar el Codigo_Almacen en CodigosGenerales
                    CodigosGenerales.Codigo_Usuario = datos_usuario.get(3);   //Guardar el Codigo_Usuario en CodigosGenerales
                    CodigosGenerales.Codigo_CentroCostos = datos_usuario.get(4);   //Guardar el Codigo_CentroCostos en CodigosGenerales
                    CodigosGenerales.Codigo_UnidadNegocio = datos_usuario.get(5);   //Guardar el Codigo_UnidadNegocio en CodigosGenerales
                    CodigosGenerales.Moneda_Empresa = datos_usuario.get(6);   //Guardar el Codigo_UnidadNegocio en CodigosGenerales
                    CodigosGenerales.Direccion_Almacen = datos_usuario.get(7);   //Guardar la direccion del almacen en CodigosGenerales
                    CodigosGenerales.Nombre_Vendedor = datos_usuario.get(8);   //Guardar el Nombre del Vendedor
                    CodigosGenerales.Celular_Vendedor = datos_usuario.get(9);   //Guardar el Celular del Vendedor
                    CodigosGenerales.email_Vendedor = datos_usuario.get(10);   //Guardar el email del Vendedor
//                    CodigosGenerales.TipoArray = "Articulos";
//                    CodigosGenerales.getArrayListArticulos("");
                    //endregion

                    Log.d(TAG, "datos_usuario - " +datos_usuario);
                } else {
                    CodigosGenerales.TipoArray = "Empresa";
                    CodigosGenerales.getArrayList("");
                }
                res.close();        //Cerrar el cursor para liberar el sqlite
                //endregion
            } catch (Exception e) {
                Log.d(TAG, "doInBackground - " + e.getMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            Fragment fragment = new FragLogin();
            if (CodigosGenerales.Login) {
                fragment = new FragMenuPrincipal();
            }
            CambiarFragment(fragment);
            super.onPostExecute(s);
        }
    }
}