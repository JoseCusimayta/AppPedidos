package yiwo.apppedidos.InterfacesPerzonalidas;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import yiwo.apppedidos.AspectosGenerales.CodigosGenerales;
import yiwo.apppedidos.Data.BDMotivo;
import yiwo.apppedidos.Data.BDPedidos;
import yiwo.apppedidos.R;

public class CustomDialogEnviarPedido {
    TextView tv_titulo, tv_motivo, tv_cliente, tv_subtotal, tv_descuento, tv_igv, tv_importe;
    Button b_aceptar, b_cancelar;
    Context context;
    BDPedidos bdPedidos = new BDPedidos();
    BDMotivo bdMotivo= new BDMotivo();
    String Correlativo;

    public interface FinalizoCuadroDialogPedido {
        void ResultadoCuadroDialogPedido(String Codigo, String Nombre);
    }

    private CustomDialogEnviarPedido.FinalizoCuadroDialogPedido interfaz;

    public CustomDialogEnviarPedido(Context context, CustomDialogEnviarPedido.FinalizoCuadroDialogPedido actividad) {

        this.context = context;
        interfaz = actividad;
        final Dialog dialogo = new Dialog(context);
        //dialogo.setCancelable(false);
        dialogo.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogo.setContentView(R.layout.custom_dialog_enviar_pedido);
        dialogo.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        tv_titulo = dialogo.findViewById(R.id.tv_titulo);
        tv_motivo = dialogo.findViewById(R.id.tv_motivo);
        tv_cliente = dialogo.findViewById(R.id.tv_cliente);
        tv_subtotal = dialogo.findViewById(R.id.tv_subtotal);
        b_aceptar = dialogo.findViewById(R.id.b_aceptar);
        b_cancelar = dialogo.findViewById(R.id.b_cerrar);
        tv_descuento = dialogo.findViewById(R.id.tv_descuento);
        tv_igv = dialogo.findViewById(R.id.tv_igv);
        tv_importe = dialogo.findViewById(R.id.tv_importe);
        Correlativo = bdMotivo.getNuevoCodigoPedido();


        tv_motivo.setText(CodigosGenerales.Nombre_Motivo + " - " + Correlativo);

        //tv_cliente.setText("Cliente: "+CodigosGenerales.Codigo_Cliente+" - "+CodigosGenerales.Nombre_Cliente);

        tv_cliente.setText("Cliente: " + CodigosGenerales.Nombre_Cliente);
        tv_subtotal.setText("SubTotal: " + CodigosGenerales.Moneda_Empresa + " " + CodigosGenerales.Precio_SubTotalPedido);
        tv_descuento.setText("Descuento:  "+ CodigosGenerales.Moneda_Empresa + " " + CodigosGenerales.Precio_DescuentoPedido);
        tv_igv.setText("IGV:  "+ CodigosGenerales.Moneda_Empresa + " " + CodigosGenerales.Precio_IGVCalcPedido);
        tv_importe.setText("Importe:  "+ CodigosGenerales.Moneda_Empresa + " " + CodigosGenerales.Precio_ImporteTotalPedido);

        tv_cliente.setText(CodigosGenerales.Nombre_Cliente);

        b_aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                interfaz.ResultadoCuadroDialogPedido(Correlativo, tv_cliente.getText().toString());
                dialogo.dismiss();
            }
        });
        b_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogo.dismiss();
            }
        });

        dialogo.show();
    }

}