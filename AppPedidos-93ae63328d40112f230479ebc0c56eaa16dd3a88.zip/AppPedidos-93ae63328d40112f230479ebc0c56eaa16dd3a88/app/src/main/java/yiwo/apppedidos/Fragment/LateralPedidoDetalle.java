package yiwo.apppedidos.Fragment;


import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;

import yiwo.apppedidos.AspectosGenerales.CodigosGenerales;
import yiwo.apppedidos.Data.BDPedidos;
import yiwo.apppedidos.InterfacesPerzonalidas.CustomAdapterNumerado;
import yiwo.apppedidos.InterfacesPerzonalidas.CustomDataModel;
import yiwo.apppedidos.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class LateralPedidoDetalle extends Fragment {


    ArrayList<List<String>> arrayList = new ArrayList<>();
    BDPedidos bdPedidos = new BDPedidos();
    ArrayList<CustomDataModel> dataModels;
    CustomAdapterNumerado adapter;
    ListView lv_items;
    ProgressBar progressBar;

    AppBarLayout app_barLayout;

    public LateralPedidoDetalle() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_lateral_pedido_detalle, container, false);

        lv_items = view.findViewById(R.id.list);
        progressBar = view.findViewById(R.id.progressBar);
        try {
            app_barLayout = getActivity().findViewById(R.id.app_barLayout);
            app_barLayout.setVisibility(View.VISIBLE);
            BackGroundTask task= new BackGroundTask();
            task.execute("");
            if (app_barLayout.getVisibility() == View.GONE)
                app_barLayout.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Log.d("FragListDeseo", "onCreateView: " + e.getMessage());
        }
        return view;
    }


    public class BackGroundTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
            dataModels = new ArrayList<>();
            lv_items.setAdapter(null);
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {

            dataModels = new ArrayList<>();
            arrayList = bdPedidos.getDetalle(CodigosGenerales.Codigo_Pedido,CodigosGenerales.Codigo_Motivo);
            for (int i = 0; i < arrayList.size(); i++) {
                dataModels.add(new CustomDataModel(
                        String.valueOf(i + 1),
                        "logo",
                        arrayList.get(i).get(2),
                        CodigosGenerales.Moneda_Empresa+" "+arrayList.get(i).get(5)+"\n" + arrayList.get(i).get(4) + " " + arrayList.get(i).get(3),
                        null,
                        arrayList.get(i).get(1),
                        ""
                ));
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            progressBar.setVisibility(View.GONE);
            try {
                adapter = new CustomAdapterNumerado(dataModels, getContext());
                lv_items.setAdapter(adapter);
            } catch (Exception e) {
                Log.d("FragListDeseo", "BackGroundTask" + e.getMessage());
            }
            super.onPostExecute(s);
        }
    }
}